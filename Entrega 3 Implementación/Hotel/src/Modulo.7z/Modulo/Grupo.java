package Modulo;

import java.util.ArrayList;
import java.util.Random; 

public class Grupo {
    private	ArrayList<Huesped> huespedes;
    private Huesped HuespedPrincipal;
    private int id_grupo;
	public Grupo(ArrayList<Huesped> huespedes, Huesped huespedPrincipal) {
		this.huespedes = huespedes;
		Random random= new Random();
		id_grupo=random.nextInt(100000000);
		HuespedPrincipal = huespedPrincipal;
		
	}
	public void anadirhuesped(Huesped nuevohuesped)
	{
		huespedes.add(nuevohuesped);
	}
	public ArrayList<Huesped> getHuespedes() {
		return huespedes;
	}
	public Huesped getHuespedPrincipal() {
		return HuespedPrincipal;
	}
	public int getId_grupo() {
		return id_grupo;
	}
	
	
    
    
	
	

}
