package Modulo;

public class Huesped {

	private String Nombre;
	private int Edad;
	private int Documento;
	private String Correo;
	private Consumo consumohuesped;
	
	public Huesped(String nombre, int edad, int documento, String correo) {
		Nombre = nombre;
		Edad = edad;
		Documento = documento;
		Correo = correo;
	}
	
	public String getNombre() {
		return Nombre;
	}
	public int getEdad() {
		return Edad;
	}
	public int getDocumento() {
		return Documento;
	}
	public String getCorreo() {
		return Correo;
	}
	public double getConsumo()
	{
		return consumohuesped.GetTotal();
	}
	
}
