package Modulo;


import java.time.LocalTime;
import java.util.ArrayList;

public class Spa implements Servicios{
    private double Tarifa;
    private LocalTime HoraInicio;
    private LocalTime HoraFinal;
    
	
    
	public Spa(double tarifa, LocalTime horaInicio, LocalTime horaFinal) {
		Tarifa = tarifa;
		HoraInicio = horaInicio;
		HoraFinal = horaFinal;
	}


	public double GetTarifa() {
		return Tarifa;
	}

	
	public ArrayList<LocalTime> GetHorarios() {
		ArrayList<LocalTime> Horarios= new ArrayList<>();
		Horarios.add(HoraInicio);
		Horarios.add(HoraFinal);
		
		return Horarios;
	}

}
